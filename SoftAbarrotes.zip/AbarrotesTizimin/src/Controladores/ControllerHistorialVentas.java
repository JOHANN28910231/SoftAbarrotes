/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import ClasesSistema.Busqueda;
import ClasesSistema.Clientes.ClientesRegistrados;
import ClasesSistema.GuardarArchivos;
import ClasesSistema.Productos.Stock;
import ClasesSistema.historial_ventas.HistorialVentas;
import ClasesSistema.historial_ventas.ProductoVendido;
import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author cmccl
 */
public class ControllerHistorialVentas implements Initializable {

    private HistorialVentas ventas;

    @FXML
    private TableColumn<ProductoVendido, String> col_Nombre;
    @FXML
    private TableColumn<ProductoVendido, Double> col_Id;
    @FXML
    private Button btn_VentasDia;
    @FXML
    private Button btn_VentasSemana;
    @FXML
    private Button btn_Menu;
    @FXML
    private Button btn_VEntasMes;
    @FXML
    private TableView<ProductoVendido> tbl_Ventas;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize( URL url, ResourceBundle rb ) {
	// TODO
	this.col_Nombre.setCellValueFactory( new PropertyValueFactory<>( "nombre" ) );
	this.col_Id.setCellValueFactory( new PropertyValueFactory<>( "montoTotal" ) );

    }

    @FXML
    private void mostrarVentasDia( ActionEvent event ) {
	this.tbl_Ventas.getItems().clear();
	Map<String, Double> ventasDelDia = ventas.obtenerVentasDelDiaDetalladas();
	mostrarVentasEnTabla( ventasDelDia );
    }

    @FXML
    private void mostrarVentasSemana( ActionEvent event ) {
	this.tbl_Ventas.getItems().clear();
	Map<String, Double> ventasDelDia = ventas.obtenerVentasDeLaSemanaDetalladas();
	mostrarVentasEnTabla( ventasDelDia );
    }

    @FXML
    private void Salir( ActionEvent event ) {
	Cerrar();
    }

    @FXML
    private void mostrarVentasMes( ActionEvent event ) {
	this.tbl_Ventas.getItems().clear();
	Map<String, Double> ventasDelDia = ventas.obtenerVentasDelMesDetalladas();
	mostrarVentasEnTabla( ventasDelDia );
    }

    void Inicializar( HistorialVentas ventas ) {
	this.ventas = ventas;
	mostrarVentasEnTabla( ventas.obtenerVentasDelDiaDetalladas() );
    }

    private void mostrarVentasEnTabla( Map<String, Double> ventas ) {
	ventas.forEach( ( nombreProducto, montoTotal ) -> {
	    ProductoVendido productoVenta = new ProductoVendido( nombreProducto, montoTotal );
	    this.tbl_Ventas.getItems().add( productoVenta );
	} );
    }

    public void Cerrar() {

	try {

	    FXMLLoader loader = new FXMLLoader( getClass().getResource( "/Vistas/Menu.fxml" ) );
	    Parent root = loader.load();

	    ControllerMenu control = loader.getController();

	    Busqueda buscador = new Busqueda();
	    Stock stock = buscador.leerStock( GuardarArchivos.getRuta() );
	    ClientesRegistrados cl = buscador.leerClientesRegistrados( GuardarArchivos.getRuta() );

	    control.Inicializar( cl );
	    control.Inicializar( stock );

	    Scene scene = new Scene( root );
	    Stage stage = new Stage();
	    stage.setScene( scene );
	    stage.show();

	    Stage myStage = (Stage) this.btn_Menu.getScene().getWindow();
	    myStage.close();

	} catch (IOException e) {
	}
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import ClasesSistema.Busqueda;
import ClasesSistema.Compras.Compra;
import ClasesSistema.GuardarArchivos;
import ClasesSistema.GuardarVentas;
import ClasesSistema.ImprimirTickets;
import ClasesSistema.Ticket;
import ClasesSistema.historial_ventas.HistorialVentas;
import com.itextpdf.text.DocumentException;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author cmccl
 */
public class ControllerCobro implements Initializable {

    @FXML
    private Button btn_Cobrar;
    @FXML
    private TextField txt_Cambio;
    @FXML
    private TextField txt_Importe;
    @FXML
    private TextField txt_Cant_Recivida;
    @FXML
    private Button btn_Imprimir;

    private Compra compras;
    private double importe;
    private float cambio;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize( URL url, ResourceBundle rb ) {
	// TODO

	this.btn_Imprimir.setDisable( true );
	this.btn_Cobrar.setDisable( false );
    }

    @FXML
    private void Cobrar( ActionEvent event ) {
	try {
	    float cantRecibida = Float.parseFloat( this.txt_Cant_Recivida.getText() );
	    this.cambio = (float) ( cantRecibida - this.importe );
	    this.compras.setCambio( cambio );
	    this.compras.setPagoCliente( cantRecibida );
	    this.txt_Cambio.setText( String.valueOf( cambio ) );
	    this.btn_Imprimir.setDisable( false );
	    this.btn_Cobrar.setDisable( true );

	} catch (NumberFormatException e) {
	    Alert alert = new Alert( Alert.AlertType.WARNING );
	    alert.setHeaderText( null );
	    alert.setTitle( "Aviso!" );
	    String aviso = "Ingrese una cantidad valida.";
	    aviso += "\nDebe ingresar numeros sin espacios ni caracteres especiales.";
	    alert.setContentText( aviso );
	    alert.showAndWait();
	}

    }

    @FXML
    private void ImprimirTicket( ActionEvent event ) {
	try {
	    Ticket ticket = new Ticket( this.compras );
	    ImprimirTickets imprimir = new ImprimirTickets();
	    imprimir.setTicket( ticket );
	    imprimir.Imprimir( GuardarArchivos.getRuta() + File.separator + "Tickets" );

	    Busqueda b = new Busqueda();

	    HistorialVentas ventas = b.leerHistorialVentas( GuardarArchivos.getRuta() );
	    GuardarVentas g = new GuardarVentas();

	    if (ventas != null) {
		ventas.agregarTicket( ticket );
		g.setVentas( ventas );
		g.GuardarArchivo( GuardarArchivos.getRuta() );
	    } else {
		ventas = new HistorialVentas();
		ventas.agregarTicket( ticket );
		g.setVentas( ventas );
		g.GuardarArchivo( GuardarArchivos.getRuta() );
	    }

	    Stage myStage = (Stage) this.btn_Imprimir.getScene().getWindow();
	    myStage.close();

	} catch (IOException | DocumentException ex) {
	    System.out.println( ex.getMessage() );
	}
    }

    public void Inicializar( Compra compras ) {
	this.compras = compras;
	this.importe = compras.getImporte();

	if (this.importe > 1000) {
	    Alert alert = new Alert( Alert.AlertType.INFORMATION );
	    alert.setHeaderText( null );
	    alert.setTitle( "Aviso!" );
	    String aviso = "El Cliente a hecho una compra mayor a $ 1,000";
	    aviso += "\nTiene un descuento del 5%";
	    alert.setContentText( aviso );
	    alert.showAndWait();

	    this.importe = this.importe * 0.95;

	    compras.setPagoCliente( (float) this.importe );
	}

	this.txt_Importe.setText( String.valueOf( this.importe ) );
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesSistema;

import java.io.Serializable;

/**
 *
 * @author DIRECCION
 */
public class Kilogramo implements Serializable{
   
    private float cant;

    public float getCant() {
        return cant;
    }

    public void setCant(float cant) {
        this.cant = cant;
    }
    
    
}

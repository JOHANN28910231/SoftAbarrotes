
package ClasesSistema;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author DIRECCION
 */
public class FechaHora implements Serializable {

    private String fechaHora;
    private LocalDateTime date;

    FechaHora() {
	date = LocalDateTime.now();

	DateTimeFormatter dtf = DateTimeFormatter.ofPattern( "dd-MM-YYYY   hh;mm a" );
	fechaHora = dtf.format( date );
    }

    public String getFechaHora() {
	return fechaHora;
    }

    public LocalDateTime getDate() {
	return date;
    }

}

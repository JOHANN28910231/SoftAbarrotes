/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesSistema.historial_ventas;

/**
 *
 * @author jj
 */
public class ProductoVendido {

    private String nombre;
    private Double montoTotal;

    public ProductoVendido( String nombre, Double montoTotal ) {
	this.nombre = nombre;
	this.montoTotal = montoTotal;
    }

    public ProductoVendido() {
    }

    public String getNombre() {
	return nombre;
    }

    public void setNombre( String nombre ) {
	this.nombre = nombre;
    }

    public Double getMontoTotal() {
	return montoTotal;
    }

    public void setMontoTotal( Double montoTotal ) {
	this.montoTotal = montoTotal;
    }

}

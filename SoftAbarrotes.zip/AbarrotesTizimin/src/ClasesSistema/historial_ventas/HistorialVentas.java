/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesSistema.historial_ventas;

import ClasesSistema.Compras.Articulo;
import ClasesSistema.Ticket;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author cmccl
 */
public class HistorialVentas implements Serializable {

    private ArrayList<Ticket> listaTickets; // Suponiendo que tienes una lista de tickets

    public HistorialVentas() {
	this.listaTickets = new ArrayList<>();
    }

    // Método para obtener ventas del día con detalles por producto
    public Map<String, Double> obtenerVentasDelDiaDetalladas() {
	LocalDate fechaActual = LocalDate.now();
	return listaTickets.stream()
		.filter( ticket -> ticket.obtenerFecha().toLocalDate().isEqual( fechaActual ) )
		.flatMap( ticket -> ticket.getCompras().getListaCompra().stream() )
		.collect( Collectors.groupingBy( Articulo::getNombre,
			Collectors.summingDouble( Articulo::getSubtotal ) ) );
    }

    // Método para obtener ventas de la semana con detalles por producto
    public Map<String, Double> obtenerVentasDeLaSemanaDetalladas() {
	LocalDate fechaActual = LocalDate.now();
	LocalDate fechaInicioSemana = fechaActual.with( java.time.temporal.TemporalAdjusters.previousOrSame( java.time.DayOfWeek.MONDAY ) );
	LocalDate fechaFinSemana = fechaInicioSemana.plusDays( 6 );

	return listaTickets.stream()
		.filter( ticket -> ticket.obtenerFecha().toLocalDate().isAfter( fechaInicioSemana.minusDays( 1 ) )
		&& ticket.obtenerFecha().toLocalDate().isBefore( fechaFinSemana.plusDays( 1 ) ) )
		.flatMap( ticket -> ticket.getCompras().getListaCompra().stream() )
		.collect( Collectors.groupingBy( Articulo::getNombre,
			Collectors.summingDouble( Articulo::getSubtotal ) ) );
    }

    // Método para obtener ventas del mes con detalles por producto
    public Map<String, Double> obtenerVentasDelMesDetalladas() {
	LocalDate fechaActual = LocalDate.now();
	LocalDate primerDiaMes = LocalDate.of( fechaActual.getYear(), fechaActual.getMonth(), 1 );
	LocalDate ultimoDiaMes = primerDiaMes.withDayOfMonth( primerDiaMes.lengthOfMonth() );

	return listaTickets.stream()
		.filter( ticket -> ticket.obtenerFecha().toLocalDate().isAfter( primerDiaMes.minusDays( 1 ) )
		&& ticket.obtenerFecha().toLocalDate().isBefore( ultimoDiaMes.plusDays( 1 ) ) )
		.flatMap( ticket -> ticket.getCompras().getListaCompra().stream() )
		.collect( Collectors.groupingBy( Articulo::getNombre,
			Collectors.summingDouble( Articulo::getSubtotal ) ) );
    }

    public void agregarTicket( Ticket ticket ) {
	this.listaTickets.add( ticket );
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesSistema;

import ClasesSistema.Compras.Compra;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 *
 * @author cmccl
 */
public class Ticket implements Serializable {

    private Compra compras;
    private FechaHora fechaHora;

    public Ticket( Compra compras ) {
	this.compras = compras;
	this.fechaHora = new FechaHora();
    }

    public Compra getCompras() {
	return compras;
    }

    public FechaHora getFechaHora() {
	return fechaHora;
    }

    public LocalDateTime obtenerFecha() {
	return fechaHora.getDate();
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesSistema;

import ClasesSistema.historial_ventas.HistorialVentas;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author cmccl
 */
public class GuardarVentas extends GuardarArchivos {

    private HistorialVentas ventas;

    @Override
    public void GuardarArchivo( String ruta ) throws IOException {
	try (FileOutputStream file = new FileOutputStream( ruta + File.separator + "recover" + File.separator + "RegistroVentas.bin" );
		ObjectOutputStream obj = new ObjectOutputStream( file )) {
	    obj.writeObject( this.ventas );
	}
    }

    @Override
    public void crearCSV( String ruta ) throws IOException {
    }

    public void setVentas( HistorialVentas ventas ) {
	this.ventas = ventas;
    }
}
